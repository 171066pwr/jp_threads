module threads {
    requires java.base;
    requires static lombok;
    requires java.desktop;
}