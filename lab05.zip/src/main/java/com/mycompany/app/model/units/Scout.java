package com.mycompany.app.model.units;

public class Scout extends Unit {
}
