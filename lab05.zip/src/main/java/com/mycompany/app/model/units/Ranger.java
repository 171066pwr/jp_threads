package com.mycompany.app.model.units;

public class Ranger extends Unit {
}
