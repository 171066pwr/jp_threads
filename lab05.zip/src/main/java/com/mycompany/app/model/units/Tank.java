package com.mycompany.app.model.units;

public class Tank extends Unit {
}
