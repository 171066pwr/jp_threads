package com.mycompany.app.model.map;

public interface Temporary {
}
