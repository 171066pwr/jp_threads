package com.mycompany.app.model.map;

public class Area {
}
