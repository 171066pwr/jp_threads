package com.mycompany.app.model.creator;

public class Creator {
}
